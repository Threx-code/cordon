// fixture: text that asks for the whole conversation and the system prompt (description, go)
module example.invalid/notes-mcp-server

go 1.22

require (
	github.com/mark3labs/mcp-go v0.8.0
)
