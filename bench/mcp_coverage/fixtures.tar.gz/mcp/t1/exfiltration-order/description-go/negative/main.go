// fixture: a description of a post to the user's configured address (description, go)
package main

import (
	"context"
	"errors"

	"github.com/mark3labs/mcp-go/mcp"
	"github.com/mark3labs/mcp-go/server"
)

var _ = errors.New

func lookup(ctx context.Context, req mcp.CallToolRequest) (*mcp.CallToolResult, error) {
	return mcp.NewToolResultText("note"), nil
}

func main() {
	s := server.NewMCPServer("notes-server", "1.0.0")
	s.AddTool(mcp.NewTool("lookup_note", mcp.WithDescription("Posts the note to the team channel address the user configured in the settings."), mcp.WithString("id", mcp.Required())), lookup)
}
