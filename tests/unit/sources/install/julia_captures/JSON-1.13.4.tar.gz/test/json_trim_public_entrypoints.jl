using Dates, JSON

const ARRAY_JSON = "[1,2,3]"
const STRING_JSON = "\"Ada\""
const TRIM_FIXTURE_DIR = joinpath(@__DIR__, "trim")

JSON.@nonstruct struct TrimCode
    value::String
end

JSON.lower(x::TrimCode) = x.value

struct TrimLeaf
    id::Int
    name::String
end

struct TrimRoot
    item::Union{Nothing,TrimLeaf}
    items::Vector{TrimLeaf}
    tags::Vector{String}
    note::Union{Nothing,String}
end

struct TrimBox{T}
    value::T
end

# Containers and a parametric struct inside a struct inside a struct.
struct TrimNested
    root::TrimRoot
    counts::Dict{String,Int}
    box::TrimBox{Vector{Int}}
end

JSON.StructUtils.@defaults struct TrimTagged
    value::Int = 0 & (json=(name="wire",),)
    secret::Int = 9 & (json=(ignore=true,),)
end

JSON.StructUtils.@noarg mutable struct TrimMutable
    value::Int = 0
end

struct TrimTemporal
    day::Dates.Date
    stamp::Dates.DateTime
    tick::Dates.Time
end

# A read style that overrides nothing: values still go through its hooks.
struct TrimReadStyle <: JSON.StructUtils.StructStyle end

struct TrimAnyField
    value::Any
end

# Close the extension point for the types produced by untyped parsing.
struct TrimJSONStyle <: JSON.JSONStyle end
JSON.applyany(::TrimJSONStyle, f, key, @nospecialize(value)) =
    throw(ArgumentError("unsupported JSON value"))

function exercise_nested_any()::Nothing
    checked(JSON.json(Dict(2 => 20, 10 => 100)) == "{\"10\":100,\"2\":20}", "numeric key sorting failed")
    text = "{\"a\":[1,\"x\",null,{\"b\":[true,1.5]}]}"
    object = JSON.parse(text, JSON.Object{String,Any})
    checked(JSON.json(object; style=TrimJSONStyle()) == text, "nested Object write failed")
    dict = JSON.parse(text, Dict{String,Any})
    checked(JSON.json(dict; style=TrimJSONStyle()) == text, "nested Dict write failed")
    io = IOBuffer()
    JSON.json(io, object; style=TrimJSONStyle(), bufsize=16)
    checked(String(take!(io)) == text, "nested IO write failed")
    return nothing
end

function checked(cond::Bool, msg::String)::Nothing
    cond || error(msg)
    return nothing
end

function exercise_lazy_entrypoints()::Nothing
    checked(JSON.lazy(ARRAY_JSON) isa JSON.LazyValue, "lazy failed")
    checked(JSON.lazyfile(joinpath(TRIM_FIXTURE_DIR, "value.json")) isa JSON.LazyValue, "lazyfile failed")
    return nothing
end

function exercise_parse_entrypoints()::Nothing
    # Open-ended untyped results are data-dependent. Narrow their runtime shape
    # before use in a safe-trim binary; `lazy` remains the arbitrary-shape path.
    untyped = JSON.parse("{\"name\":\"Ada\"}")
    checked(untyped isa JSON.Object{String,Any}, "untyped object parse failed")
    name = (untyped::JSON.Object{String,Any})["name"]
    checked(name isa String, "untyped string shape failed")
    checked((name::String) == "Ada", "untyped string value failed")

    checked(JSON.parse("7", Int) == 7, "typed scalar parse failed")
    checked(JSON.parse("7", Int; error_context=false) == 7, "disabled diagnostics parse failed")
    checked(JSON.parse(JSON.lazy(ARRAY_JSON), Vector{Int}; error_context=false) == [1, 2, 3],
        "disabled diagnostics lazy parse failed")
    checked(JSON.parse(IOBuffer(STRING_JSON), String) == "Ada", "typed IO parse failed")
    checked(JSON.parse(ARRAY_JSON, Vector{Int}) == [1, 2, 3], "typed array parse failed")
    checked(JSON.parse("{\"score\":7}", Dict{String,Int}) == Dict("score" => 7),
        "typed dictionary parse failed")
    checked(JSON.parse("[7,\"Ada\"]", Tuple{Int,String}) == (7, "Ada"), "typed tuple parse failed")
    checked(JSON.parse("[]", Tuple{}) == (), "empty tuple parse failed")
    checked(JSON.parse("{\"a\":7,\"b\":\"Ada\"}", Tuple{Int,String}) == (7, "Ada"), "object tuple parse failed")
    extra = try
        JSON.parse("[7,\"Ada\",1]", Tuple{Int,String}; unknown_fields=:error)
        nothing
    catch err
        err
    end
    checked(extra isa ArgumentError, "extra tuple member diagnostic failed")

    root = JSON.parse(
        "{\"item\":{\"id\":1,\"name\":\"one\"},\"items\":[{\"id\":2,\"name\":\"two\"}],\"tags\":[\"a\"],\"note\":null}",
        TrimRoot,
    )
    checked(root.item !== nothing && root.item.id == 1, "nested struct parse failed")
    checked(length(root.items) == 1 && root.items[1].name == "two",
        "nested vector parse failed")
    checked(root.tags == ["a"] && root.note === nothing, "nullable field parse failed")

    disabled = JSON.parse(
        "{\"item\":null,\"items\":[],\"tags\":[],\"note\":null}", TrimRoot;
        error_context=false,
    )
    checked(disabled.item === nothing && isempty(disabled.items),
        "disabled diagnostics nested parse failed")

    tagged = JSON.parse(
        "{\"wire\":4,\"secret\":99}",
        TrimTagged;
        unknown_fields=:error,
    )
    checked(tagged == TrimTagged(4, 9), "field-tag parse failed")

    mutable_value = TrimMutable()
    JSON.parse!("{\"value\":8}", mutable_value; unknown_fields=:error)
    checked(mutable_value.value == 8, "parse! failed")
    JSON.parse!(IOBuffer("{\"value\":9}"), mutable_value; error_context=false)
    checked(mutable_value.value == 9, "disabled diagnostics IO parse! failed")
    JSON.parse!(JSON.lazy("{\"value\":10}"), mutable_value; error_context=false)
    checked(mutable_value.value == 10, "disabled diagnostics lazy parse! failed")

    unknown = try
        JSON.parse("{\"extra\":1}", TrimLeaf; unknown_fields=:error)
        nothing
    catch err
        err
    end
    checked(unknown isa ArgumentError, "unknown-field diagnostic failed")

    deep = try
        JSON.parse(repeat("{\"item\":", 600), TrimRoot)
        nothing
    catch err
        err
    end
    msg = deep isa ArgumentError ? (deep::ArgumentError).msg : ""
    checked(msg isa String && occursin("maxdepth", msg::String), "maxdepth diagnostic failed")
    checked(JSON.parse("[[1]]", Vector{Vector{Int}}; maxdepth=2) == [[1]], "maxdepth keyword parse failed")
    return nothing
end

function exercise_custom_style_parse()::Nothing
    style = TrimReadStyle()
    checked(JSON.parse("42", Int64; style) == 42, "custom-style scalar parse failed")
    leaf = JSON.parse("{\"id\":1,\"name\":\"one\"}", TrimLeaf; style)
    checked(leaf.id == 1 && leaf.name == "one", "custom-style struct parse failed")
    text = "{\"value\":{\"a\":[1,1.5,\"x\",null,true,{\"b\":12345678901234567890123}]}}"
    any_field = JSON.parse(text, TrimAnyField; style)
    object = any_field.value::JSON.Object{String,Any}
    values = object["a"]::Vector{Any}
    checked(length(values) == 6, "custom-style nested array length failed")
    checked((values[1]::Int64) == 1 && (values[2]::Float64) == 1.5, "custom-style nested numbers failed")
    checked((values[3]::String) == "x" && values[4] === nothing && (values[5]::Bool),
        "custom-style nested scalars failed")
    inner = values[6]::JSON.Object{String,Any}
    checked((inner["b"]::BigInt) == big"12345678901234567890123", "custom-style nested bigint failed")
    dict = JSON.parse("{\"k\":{\"n\":[2]}}", Dict{String,Any}; style)
    nested = dict["k"]::JSON.Object{String,Any}
    checked(((nested["n"]::Vector{Any})[1]::Int64) == 2, "custom-style dictionary parse failed")
    mismatch = try
        JSON.parse("[1]", Int64; style)
        nothing
    catch err
        err
    end
    checked(mismatch isa MethodError, "custom-style mismatch did not throw a MethodError")
    return nothing
end

function exercise_write_entrypoints()::Nothing
    obj = JSON.Object{String, Int}("score" => 7.0)
    obj[:score] = 10
    checked(obj.score == 10, "Object property access failed")
    names = propertynames(obj)
    checked(names isa Tuple{Symbol}, "Object property names shape failed")
    checked((names::Tuple{Symbol}) == (:score,), "Object property names failed")
    checked(haskey(obj, "score"), "Object setindex! failed")
    delete!(obj, :score)
    checked(!haskey(obj, "score"), "Object delete! failed")
    checked(setindex!(obj, 11, :score) === obj, "Object insertion must return the object")
    checked(pop!(obj, :score) == 11, "Object keyed pop! failed")
    checked(pop!(obj, :score, -1) == -1, "Object pop! default failed")
    obj["first"] = 1
    obj["last"] = 2
    checked(pop!(obj) == ("last" => 2), "Object last-pair pop! failed")
    checked(popfirst!(obj) == ("first" => 1), "Object popfirst! failed")
    checked(isempty(obj), "Object remains nonempty after popping its pairs")
    checked(isempty(propertynames(obj)), "Empty Object property names failed")

    duplicates = JSON.Object("a" => 1, "a" => 2, "b" => 3)
    duplicate_names = propertynames(duplicates)
    checked(duplicate_names isa NTuple{3,Symbol}, "Duplicate Object property names shape failed")
    checked((duplicate_names::NTuple{3,Symbol}) == (:a, :a, :b), "Duplicate Object property names failed")
    checked(delete!(duplicates, :a) === duplicates, "Object deletion must return the object")
    checked(JSON.json(duplicates) == "{\"b\":3}", "Object deletion retained a duplicate key")

    checked(JSON.json([1, 2, 3]) == ARRAY_JSON, "json string output failed")

    io = IOBuffer()
    JSON.json(io, [1, 2, 3]; pretty = 2)
    checked(String(take!(io)) == "[\n  1,\n  2,\n  3\n]", "pretty IO json output failed")

    print_io = IOBuffer()
    JSON.print(print_io, [1, 2, 3], 2)
    checked(String(take!(print_io)) == "[\n  1,\n  2,\n  3\n]", "JSON.print failed")

    jsonlines = JSON.json([[1], [2]]; jsonlines = true)
    checked(jsonlines == "[1]\n[2]\n", "jsonlines write failed")
    checked(JSON.json(JSON.JSONText("{\"raw\":true}")) == "{\"raw\":true}", "JSONText write failed")
    checked(JSON.json(JSON.Null()) == "null", "JSON.Null write failed")
    checked(JSON.json(TrimCode("beta")) == "\"beta\"", "custom lower write failed")
    nested = TrimNested(
        TrimRoot(TrimLeaf(1, "a"), [TrimLeaf(2, "b")], ["x"], nothing),
        Dict("n" => 1),
        TrimBox([1, 2]),
    )
    checked(
        JSON.json(nested) ==
        "{\"root\":{\"item\":{\"id\":1,\"name\":\"a\"},\"items\":[{\"id\":2,\"name\":\"b\"}]," *
        "\"tags\":[\"x\"],\"note\":null},\"counts\":{\"n\":1},\"box\":{\"value\":[1,2]}}",
        "nested struct write failed",
    )

    # Date, DateTime, and Time round-trip through their canonical ISO text.
    temporal = TrimTemporal(
        Dates.Date(2026, 8, 7),
        Dates.DateTime(2026, 8, 7, 15, 0, 0, 76),
        Dates.Time(12, 30, 15, 250),
    )
    temporal_json = JSON.json(temporal)
    checked(
        temporal_json ==
        "{\"day\":\"2026-08-07\",\"stamp\":\"2026-08-07T15:00:00.076\",\"tick\":\"12:30:15.25\"}",
        "temporal write failed",
    )
    checked(
        JSON.parse(temporal_json, TrimTemporal) == temporal,
        "temporal read failed",
    )
    checked(
        JSON.json(Dates.DateTime(2026, 1, 1)) == "\"2026-01-01T00:00:00\"",
        "zero-millisecond DateTime write failed",
    )
    return nothing
end

function run_json_trim_public_entrypoints()::Nothing
    exercise_lazy_entrypoints()
    exercise_parse_entrypoints()
    exercise_custom_style_parse()
    exercise_write_entrypoints()
    exercise_nested_any()
    return nothing
end

function @main(args::Vector{String})::Cint
    _ = args
    run_json_trim_public_entrypoints()
    return 0
end

Base.Experimental.entrypoint(main, (Vector{String},))
