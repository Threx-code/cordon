"""
    JSON.parse(json)
    JSON.parse(json, T)
    JSON.parse!(json, x)
    JSON.parsefile(filename)
    JSON.parsefile(filename, T)
    JSON.parsefile!(filename, x)

Parse a JSON input (string, vector, stream, LazyValue, etc.) into a Julia value. The `parsefile` variants
take a filename, open the file, and pass the `IOStream` to `parse`.

Currently supported keyword arguments include:
  * `allownan`: allows parsing `NaN`, `Inf`, and `-Inf` since they are otherwise invalid JSON
  * `ninf`: string to use for `-Inf` (default: `"-Infinity"`)
  * `inf`: string to use for `Inf` (default: `"Infinity"`)
  * `nan`: string to use for `NaN` (default: `"NaN"`)
  * `jsonlines`: treat the `json` input as an implicit JSON array, delimited by newlines, each element being parsed from each row/line in the input
  * `isroot`: whether this is the root LazyValue encompassing the entire json buffer. If `false` parses only the first JSON value and ignores trailing characters. (default: `true`)
  * `maxdepth`: the deepest nesting of objects and arrays that will be parsed; deeper input throws an `ArgumentError` instead of overflowing the stack (default: `512`)
  * `dicttype`: a custom `AbstractDict` type to use instead of `$DEFAULT_OBJECT_TYPE` as the default type for JSON object materialization
  * `null`: a custom value to use for JSON null values (default: `nothing`)
  * `unknown_fields`: controls how unmatched JSON object keys or positional values are handled when parsing into a target type or existing object; supported values are `:ignore` (default) and `:error`
  * `error_context`: when `true`, wrap materialization failures in [`ParseError`](@ref) with an input path, value-start byte position, original exception and backtrace (default: `false`)
  * `style`: a custom `StructUtils.StructStyle` subtype instance to be used in calls to `StructUtils.make` and `StructUtils.lift`. This allows overriding
    default behaviors for non-owned types.

The methods without a type specified (`JSON.parse(json)`, `JSON.parsefile(filename)`), do a generic materialization into
predefined default types, including:
  * JSON object => `$DEFAULT_OBJECT_TYPE` (**see note below**)
  * JSON array => `Vector{Any}`
  * JSON string => `String`
  * JSON number => `Int64`, `BigInt`, `Float64`, or `BigFloat`
  * JSON true => `true`
  * JSON false => `false`
  * JSON null => `nothing`

When a type `T` is specified (`JSON.parse(json, T)`, `JSON.parsefile(filename, T)`), materialization to a value
of type `T` will be attempted utilizing machinery and interfaces provided by the StructUtils.jl package, including:
  * For JSON objects, JSON keys will be matched against field names of `T` with a value being constructed via `T(args...)`
  * If `T` was defined with the `@noarg` macro, an empty instance will be constructed, and field values set as JSON keys match field names
  * If `T` had default field values defined using the `@defaults` or `@kwarg` macros (from StructUtils.jl package), those will be set in the value of `T` unless different values are parsed from the JSON
  * If `T` was defined with the `@nonstruct` macro, the struct will be treated as a primitive type and constructed using the `lift` function rather than from field values
  * JSON keys that don't match field names in `T` will be ignored (skipped over) by default; pass `unknown_fields=:error` to reject them
  * If a field in `T` has a `name` fieldtag, the `name` value will be used to match JSON keys instead
  * If `T` or any recursive field type of `T` is abstract, an appropriate `JSON.@choosetype T x -> ...` definition should exist for "choosing" a concrete type at runtime; default type choosing exists for `Union{T, Missing}` and `Union{T, Nothing}` where the JSON value is checked if `null`. If the `Any` type is encountered, the default materialization types will be used (`JSON.Object`, `Vector{Any}`, etc.)
  * For any non-JSON-standard non-aggregate (i.e. non-object, non-array) field type of `T`, a `JSON.lift(::Type{T}, x) = ...` definition can be defined for how to "lift" the default JSON value (String, Number, Bool, `nothing`) to the type `T`; a default lift definition exists, for example, for `JSON.lift(::Type{Missing}, x) = missing` where the standard JSON value for `null` is `nothing` and it can be "lifted" to `missing`
  * For any `T` or recursive field type of `T` that is `AbstractDict`, non-string/symbol/integer keys will need to have a `StructUtils.liftkey(::Type{T}, x)` definition for how to "lift" the JSON string key to the key type of `T`

For any `T` or recursive field type of `T` that is `JSON.JSONText`, the next full raw JSON value will be preserved in the `JSONText` wrapper as-is.

For the unique case of nested JSON arrays and prior knowledge of the expected dimensionality,
a target type `T` can be given as an `AbstractArray{T, N}` subtype. In this case, the JSON array data is materialized as an
n-dimensional array, where: the number of JSON array nestings must match the Julia array dimensionality (`N`),
nested JSON arrays at matching depths are assumed to have equal lengths, and the length of
the innermost JSON array is the 1st dimension length and so on. For example, the JSON array `[[[1.0,2.0]]]`
would be materialized as a 3-dimensional array of `Float64` with sizes `(2, 1, 1)`, when called
like `JSON.parse("[[[1.0,2.0]]]", Array{Float64, 3})`. Note that n-dimensional Julia
arrays are written to json as nested JSON arrays by default, to enable lossless re-parsing,
though the dimensionality must still be provided explicitly to the call to `parse` (i.e. default parsing via `JSON.parse(json)`
will result in plain nested `Vector{Any}`s returned).

Examples:
```julia
using Dates

abstract type AbstractMonster end

struct Dracula <: AbstractMonster
    num_victims::Int
end

struct Werewolf <: AbstractMonster
    witching_hour::DateTime
end

JSON.@choosetype AbstractMonster x -> x.monster_type[] == "vampire" ? Dracula : Werewolf

struct Percent <: Number
    value::Float64
end

JSON.lift(::Type{Percent}, x) = Percent(Float64(x))
StructUtils.liftkey(::Type{Percent}, x::String) = Percent(parse(Float64, x))

@defaults struct FrankenStruct
    id::Int = 0
    name::String = "Jim"
    address::Union{Nothing, String} = nothing
    rate::Union{Missing, Float64} = missing
    type::Symbol = :a &(json=(name="franken_type",),)
    notsure::Any = nothing
    monster::AbstractMonster = Dracula(0)
    percent::Percent = Percent(0.0)
    birthdate::Date = Date(0) &(json=(dateformat="yyyy/mm/dd",),)
    percentages::Dict{Percent, Int} = Dict{Percent, Int}()
    json_properties::JSONText = JSONText("")
    matrix::Matrix{Float64} = Matrix{Float64}(undef, 0, 0)
end

json = \"\"\"
{
    "id": 1,
    "address": "123 Main St",
    "rate": null,
    "franken_type": "b",
    "notsure": {"key": "value"},
    "monster": {
        "monster_type": "vampire",
        "num_victims": 10
    },
    "percent": 0.1,
    "birthdate": "2023/10/01",
    "percentages": {
        "0.1": 1,
        "0.2": 2
    },
    "json_properties": {"key": "value"},
    "matrix": [[1.0, 2.0], [3.0, 4.0]],
    "extra_key": "extra_value"
}
\"\"\"
JSON.parse(json, FrankenStruct)
# FrankenStruct(1, "Jim", "123 Main St", missing, :b, JSON.Object{String, Any}("key" => "value"), Dracula(10), Percent(0.1), Date("2023-10-01"), Dict{Percent, Int64}(Percent(0.2) => 2, Percent(0.1) => 1), JSONText("{\"key\": \"value\"}"), [1.0 3.0; 2.0 4.0])
```

Let's walk through some notable features of the example above:
  * The `name` field isn't present in the JSON input, so the default value of `"Jim"` is used.
  * The `address` field is a `Union{Nothing, String}` and its JSON value is not `null`, so a `String` is parsed.
  * The `rate` field is a `Union{Missing, Float64}` and its JSON value is `null`, so it becomes `missing`.
  * The `type` field is a `Symbol`, and has a fieldtag `json=(name="franken_type",)` which means the JSON key `franken_type` will be used to set the field value instead of the default `type` field name. A default `lift` definition for `Symbol` is used to convert the JSON string value to a `Symbol`.
  * The `notsure` field is of type `Any`, so the default object type `JSON.Object{String, Any}` is used to materialize the JSON value.
  * The `monster` field is a polymorphic type, and the JSON value has a `monster_type` key that determines which concrete type to use. The `@choosetype` macro is used to define the logic for choosing the concrete type based on the JSON input. Note that the `x` in `@choosetype` is a `LazyValue`, so we materialize via `x.monster_type[]` in order to compare with the string `"vampire"`.
  * The `percent` field is a custom type `Percent` and the `JSON.lift` method defines how to construct a `Percent` from the JSON value, which is a `Float64` in this case.
  * The `birthdate` field is parsed with the date format given by its `dateformat` field tag.
  * The `percentages` field is a dictionary with keys of type `Percent`, which is a custom type. The `liftkey` function is defined to convert the JSON string keys to `Percent` types (parses the Float64 manually)
  * The `json_properties` field has a type of `JSONText`, which means the raw JSON will be preserved as a String of the `JSONText` type.
  * The `matrix` field is a `Matrix{Float64}`, so the JSON input array-of-arrays are materialized as such.
  * The `extra_key` field is not defined in the `FrankenStruct` type, so it is ignored and skipped over.

NOTE:
Why use `JSON.Object{String, Any}` as the default object type? It provides several benefits:
  * Behaves as a drop-in replacement for `Dict{String, Any}`, so no loss of functionality
  * Performance! Its internal representation means memory savings and faster construction for small objects typical in JSON (vs `Dict`)
  * Insertion order is preserved, so the order of keys in the JSON input is preserved in `JSON.Object`
  * Convenient `getproperty` (i.e. `obj.key`) syntax is supported, even for `Object{String,Any}` key types (again ideal/specialized for JSON usage)

`JSON.Object` internal representation uses a linked list, thus key lookups are linear time (O(n)). For *large* JSON objects,
(hundreds or thousands of keys), consider using a `Dict{String, Any}` instead, like `JSON.parse(json; dicttype=Dict{String, Any})`.
"""
function parse end

import StructUtils: StructStyle

abstract type JSONStyle <: StructStyle end

# defining a custom style allows us to pass a non-default dicttype `O` through JSON.parse,
# while still delegating custom behavior to an inner StructStyle if one was provided
struct JSONReadStyle{O,T,S,C} <: JSONStyle
    null::T
    style::S
    ignore_unknown_fields::Bool
    context::C
end

JSONReadStyle{O}(null::T, style::S=StructUtils.DefaultStyle(), ignore_unknown_fields::Bool=true) where {O,T,S} =
    JSONReadStyle{O,T,S,Nothing}(null, style, ignore_unknown_fields, nothing)

JSONReadStyle{O,T,S}(null::T, style::S, ignore_unknown_fields::Bool) where {O,T,S} =
    JSONReadStyle{O,T,S,Nothing}(null, style, ignore_unknown_fields, nothing)

struct _ParseFailure
    position::Int
    jsonlines::Bool
    cause::Any
    backtrace::Any
end

mutable struct _ErrorContext{B}
    buffer::B
    failure::Union{Nothing,_ParseFailure}
end
_ErrorContext(x::LazyValues) = _ErrorContext(getbuf(x), nothing)

_contextstyle(st::JSONReadStyle{O,T,S}, context::C) where {O,T,S,C} =
    JSONReadStyle{O,T,S,C}(st.null, st.style, st.ignore_unknown_fields, context)

_contextfatal(err) = err isa Union{InterruptException,OutOfMemoryError,StackOverflowError}

@noinline function _recordfailure!(context::_ErrorContext, saved, err, x::LazyValues)
    bt = catch_backtrace()
    child = context.failure
    # A hook may catch a failure and later throw the same exception again.
    # Only a new child record with the same original backtrace is propagating.
    if !(child !== nothing && child !== saved && child.cause === err && child.backtrace == bt)
        context.failure = getbuf(x) === context.buffer ?
            _ParseFailure(getpos(x), getopts(x).jsonlines, err, bt) : nothing
    end
    return context.failure
end

struct _ContextCallback{F,C}
    f::F
    context::C
end
function (f::_ContextCallback)(k, v)
    saved = f.context.failure
    try
        result = f.f(k, v)
        f.context.failure = saved
        return result
    catch err
        _contextfatal(err) && rethrow()
        _recordfailure!(f.context, saved, err, v)
        rethrow()
    end
end

@inline _contextcallback(ctx, f) = f
@inline _contextcallback(st::JSONReadStyle{O,T,S,<:_ErrorContext}, f) where {O,T,S} =
    _ContextCallback(f, st.context)

# The untyped parser carries its null value separately from typed style hooks.
struct _UntypedContext{N,C}
    null::N
    context::C
end
@inline _contextcallback(ctx::_UntypedContext, f) = _ContextCallback(f, ctx.context)
_untypednull(null) = null
_untypednull(ctx::_UntypedContext) = ctx.null
_untypedcontext(null, st::StructStyle) = null
_untypedcontext(null, st::JSONReadStyle{O,T,S,<:_ErrorContext}) where {O,T,S} =
    _UntypedContext(null, st.context)
# A style supplied as the null value retains its existing applyvalue dispatch.
_untypedcontext(null::StructStyle, st::JSONReadStyle{O,T,S,<:_ErrorContext}) where {O,T,S} = null

@inline _contextmake(st::StructStyle, ::Type{T}, x) where {T} = StructUtils.make(st, T, x)
function _contextmake(st::JSONReadStyle{O,N,S,<:_ErrorContext}, ::Type{T}, x) where {O,N,S,T}
    saved = st.context.failure
    try
        result = StructUtils.make(st, T, x)
        st.context.failure = saved
        return result
    catch err
        _contextfatal(err) && rethrow()
        _recordfailure!(st.context, saved, err, x)
        rethrow()
    end
end

# Return a pointer suffix when found, otherwise the next byte position. Returning
# positions lets the existing traversal avoid rescanning completed subtrees.
function _failurepath(x::LazyValues, failure::_ParseFailure)
    if getpos(x) == failure.position && getopts(x).jsonlines == failure.jsonlines
        return StructUtils.EarlyReturn("")
    end
    type = gettype(x)
    if type == JSONTypes.OBJECT || type == JSONTypes.ARRAY
        callback = function (k, v)
            getpos(v) > failure.position && return StructUtils.EarlyReturn(nothing)
            found = _failurepath(v, failure)
            if found isa StructUtils.EarlyReturn
                found.value === nothing && return found
                key = type == JSONTypes.ARRAY ? string(k - 1) : String(k)
                token = replace(key, "~" => "~0", "/" => "~1")
                return StructUtils.EarlyReturn(string('/', token, found.value))
            end
            return found
        end
        return type == JSONTypes.OBJECT ? applyobject(callback, x) : applyarray(callback, x)
    end
    return skip(x)
end

function _withparsecontext(f::F, root::LazyValue, context::_ErrorContext) where {F}
    try
        return f()
    catch err
        _contextfatal(err) && rethrow()
        failure = _recordfailure!(context, nothing, err, root)::_ParseFailure
        path = try
            found = _failurepath(root, failure)
            found isa StructUtils.EarlyReturn ? found.value : nothing
        catch recovery
            _contextfatal(recovery) && rethrow()
            nothing
        end
        throw(ParseError(path, failure.position, failure.cause, failure.backtrace))
    end
end

function _parsecontext(x, ::Type{T}, dicttype, null, style) where {T}
    context = _ErrorContext(x)
    return _withparsecontext(x, context) do
        _parse(x, T, dicttype, null, _contextstyle(style, context))
    end
end

function _parsecontext!(x, obj, style)
    context = _ErrorContext(x)
    return _withparsecontext(x, context) do
        StructUtils.make!(_contextstyle(style, context), obj, x)
    end
end

objecttype(::StructStyle) = DEFAULT_OBJECT_TYPE
objecttype(::JSONReadStyle{OT}) where {OT} = OT
nullvalue(::StructStyle) = nothing
nullvalue(st::JSONReadStyle) = st.null

# Custom styles retain the generic make/lift hooks, including lazy-source lifts.
const _DefaultReadStyle = JSONReadStyle{O,N,StructUtils.DefaultStyle} where {O,N}

StructUtils.initialize(::JSONReadStyle, ::Type{Object}, source) = DEFAULT_OBJECT_TYPE()

# this allows struct fields to specify tags under the json key specifically to override JSON behavior
StructUtils.fieldtagkey(::JSONStyle) = :json
StructUtils.defaultstate(st::JSONReadStyle) = StructUtils.defaultstate(st.style)
StructUtils.orderedfields(::JSONReadStyle) = true

# the caller's style answers type traits (`dictlike`, `structlike`, ...) that have no JSON method
StructUtils.parentstyle(st::JSONReadStyle) = st.style

function jsonreadstyle(::Type{T}, ::Type{O}, null, style::StructStyle, unknown_fields::Symbol) where {T,O}
    ignore_unknown_fields =
        unknown_fields === :ignore ? true :
        unknown_fields === :error ? false :
        throw(ArgumentError(string(
            "`unknown_fields` must be `:ignore` or `:error`, got ",
            _unknownoption(unknown_fields),
        )))
    if T === Any && !ignore_unknown_fields
        throw(ArgumentError("`unknown_fields` is only supported when parsing into a target type or existing object"))
    end
    return JSONReadStyle{O}(null, style, ignore_unknown_fields)
end

# Use the writer's existing byte escape table. This keeps error text accurate
# without pulling generic `repr` and type-display machinery into trim images.
function _quotedstring(key::AbstractString)
    n = escapelength(key) + 2
    buf = Vector{UInt8}(undef, n)
    _string(buf, 1, key, nothing, n)
    return String(buf)
end

function _unknownoption(option::Symbol)
    value = String(option)
    return Base.isidentifier(value) ? string(':', value) :
        string("Symbol(", _quotedstring(value), ')')
end
_unknownkey(key::PtrString) = _quotedstring(String(key))
_unknownkey(key::AbstractString) = _quotedstring(key)
_unknownkey(key::Symbol) = _unknownoption(key)
_unknownkey(key::Integer) = string(key)
_unknownkey(key) = "<key>"

@noinline unknownfielderror(::Type{T}, key) where {T} = ArgumentError(string(
    "encountered unknown JSON member ",
    _unknownkey(key),
    " while parsing `",
    _typename(T),
    "`",
))

function StructUtils.unknownfield(st::JSONReadStyle, ::Type{T}, key, value) where {T}
    st.ignore_unknown_fields || throw(unknownfielderror(T, key))
    st isa _DefaultReadStyle && return StructUtils.unknownfield(st.style, T, key, value)
    # a custom style's hook is user code: a PtrString points into the input, valid only during the parse
    return StructUtils.unknownfield(st.style, T, key isa PtrString ? String(key) : key, value)
end

"See [`parse`](@ref)."
function parsefile end

"See [`parse`](@ref)."
function parsefile! end

parsefile(file; jsonlines::Union{Bool,Nothing}=nothing, kw...) = open(io -> parse(io; jsonlines=(jsonlines === nothing ? isjsonl(file) : jsonlines), kw...), file)
parsefile(file, ::Type{T}; jsonlines::Union{Bool,Nothing}=nothing, kw...) where {T} = open(io -> parse(io, T; jsonlines=(jsonlines === nothing ? isjsonl(file) : jsonlines), kw...), file)
parsefile!(file, x::T; jsonlines::Union{Bool,Nothing}=nothing, kw...) where {T} = open(io -> parse!(io, x; jsonlines=(jsonlines === nothing ? isjsonl(file) : jsonlines), kw...), file)

parse(io::Union{IO,Base.AbstractCmd}, ::Type{T}=Any; kw...) where {T} = parse(Base.read(io), T; kw...)

# Keep literal options visible through the mutating entrypoints in native builds.
@inline parse!(io::Union{IO,Base.AbstractCmd}, x::T; kw...) where {T} = parse!(Base.read(io), x; kw...)

# Absence is known from the keyword tuple's type, so default calls do not infer
# the diagnostics path. Remove only this option before forwarding lazy options.
function _errorcontext(kw)
    value = get(kw, :error_context, false)
    value isa Bool || throw(TypeError(Symbol("keyword argument"), :error_context, Bool, value))
    return value
end

_withoutcontext(kw) = Base.structdiff(values(kw), NamedTuple{(:error_context,)})

# Buffer customization stays at the StructUtils style/make/lift boundary;
# a parse method specialized on LazyValue applies to direct LazyValue inputs.
function parse(buf::Union{AbstractVector{UInt8},AbstractString}, ::Type{T}=Any;
    dicttype::Type{O}=DEFAULT_OBJECT_TYPE, null=nothing, style::StructStyle=StructUtils.DefaultStyle(),
    unknown_fields::Symbol=:ignore, kw...) where {T,O}
    error_context = _errorcontext(kw)
    x = lazy(buf; _withoutcontext(kw)...)
    st = jsonreadstyle(T, O, null, style, unknown_fields)
    return error_context ? _parsecontext(x, T, dicttype, null, st) : _parse(x, T, dicttype, null, st)
end

@inline function parse!(buf::Union{AbstractVector{UInt8},AbstractString}, x::T;
    dicttype::Type{O}=DEFAULT_OBJECT_TYPE, null=nothing, style::StructStyle=StructUtils.DefaultStyle(),
    unknown_fields::Symbol=:ignore, kw...) where {T,O}
    error_context = _errorcontext(kw)
    st = jsonreadstyle(T, O, null, style, unknown_fields)
    source = lazy(buf; _withoutcontext(kw)...)
    return error_context ? _parsecontext!(source, x, st) : _parse!(source, x, st)
end

function parse(x::LazyValue, ::Type{T}=Any;
    dicttype::Type{O}=DEFAULT_OBJECT_TYPE, null=nothing, style::StructStyle=StructUtils.DefaultStyle(),
    unknown_fields::Symbol=:ignore, kw...) where {T,O}
    error_context = _errorcontext(kw)
    isempty(_withoutcontext(kw)) || Base.kwerr(values(kw), parse, x, T)
    st = jsonreadstyle(T, O, null, style, unknown_fields)
    return error_context ? _parsecontext(x, T, dicttype, null, st) : _parse(x, T, dicttype, null, st)
end

function _parse(x::LazyValue, ::Type{T}, dicttype::Type{O}, null, style::StructStyle) where {T,O}
    y, pos = StructUtils.make(style, T, x)
    getisroot(x) && checkendpos(x, T, pos)
    return y
end

mutable struct ValueClosure
    value::Any
    ValueClosure() = new()
end

(f::ValueClosure)(v) = setfield!(f, :value, v)

function _parse(x::LazyValue, ::Type{Any}, ::Type{DEFAULT_OBJECT_TYPE}, null, st::StructStyle)
    out = ValueClosure()
    pos = applyvalue(out, x, _untypedcontext(null, st))
    getisroot(x) && checkendpos(x, Any, pos)
    return out.value
end

@inline function parse!(x::LazyValue, obj::T;
    dicttype::Type{O}=DEFAULT_OBJECT_TYPE, null=nothing, style::StructStyle=StructUtils.DefaultStyle(),
    unknown_fields::Symbol=:ignore, kw...) where {T,O}
    error_context = _errorcontext(kw)
    isempty(_withoutcontext(kw)) || Base.kwerr(values(kw), parse!, x, obj)
    st = jsonreadstyle(T, O, null, style, unknown_fields)
    return error_context ? _parsecontext!(x, obj, st) : _parse!(x, obj, st)
end

# Compile typed mutation separately from the inlined keyword forwarders.
@noinline _parse!(x::LazyValue, obj, style::StructStyle) = StructUtils.make!(style, obj, x)

# for LazyValue, if x started at the beginning of the JSON input,
# then we want to ensure that the entire input was consumed
# and error if there are any trailing invalid JSON characters
function checkendpos(x::LazyValue, ::Type{T}, pos::Int) where {T}
    buf = getbuf(x)
    len = getlength(buf)
    if pos <= len
        b = getbyte(buf, pos)
        while b == UInt8('\t') || b == UInt8(' ') || b == UInt8('\n') || b == UInt8('\r')
            pos += 1
            pos > len && break
            b = getbyte(buf, pos)
        end
    end
    if (pos - 1) != len
        invalid(InvalidChar, buf, pos, T)
    end
    return nothing
end

# builds an Object from parsed key-value pairs: a new key is appended after the
# latest leaf node. Once the object has 5 keys, a set tracks the keys seen so far;
# the first repeated key after that builds a table of each key's node, so repeated
# keys are overwritten without scanning the list
mutable struct ObjectClosure{K,V,T}
    root::Object{K,V}
    obj::Object{K,V}
    keys::Union{Nothing,Set{K}}
    nodes::Union{Nothing,Dict{K,Object{K,V}}}
    count::Int
    ctx::T # the null value/diagnostic context of an untyped parse, or a typed style
end

ObjectClosure(obj::Object{K,V}, ctx::T) where {K,V,T} = ObjectClosure{K,V,T}(obj, obj, nothing, nothing, 0, ctx)

@inline function insert_or_overwrite!(oc::ObjectClosure{K,V}, key, val) where {K,V}
    # Scan at most four entries before allocating a hash table for larger objects.
    keys = oc.keys
    if keys === nothing
        node = find_node_by_key(oc.root, key)
        if node !== nothing
            setfield!(node, :value, convert(V, val))
            return
        end
        oc.count += 1
        if oc.count == 5
            keys = sizehint!(Set{K}(), 16)
            node = _ch(oc.root)
            while node isa Object{K,V}
                push!(keys, _k(node)::K)
                node = _ch(node)
            end
            push!(keys, key)
            oc.keys = keys
        end
    elseif _in!(key, keys)
        setfield!(nodeforkey!(oc, key), :value, convert(V, val))
        return
    end
    # this uses an "unsafe" constructor that returns the new leaf node
    # and sets the child of the previous node to the new node
    oc.obj = Object{K,V}(oc.obj, key, val) # fast append path
    nodes = oc.nodes
    nodes === nothing || (nodes[_k(oc.obj)::K] = oc.obj)
    return
end

# the node of a key already in the object; the table is built on first use
@noinline function nodeforkey!(oc::ObjectClosure{K,V}, key) where {K,V}
    nodes = oc.nodes
    if nodes === nothing
        nodes = oc.nodes = nodetable(oc.root, length(oc.keys::Set{K}))
    end
    return nodes[key]
end

# each key's node; a repeated key maps to its first node, the one `setindex!` updates
function nodetable(root::Object{K,V}, n::Int) where {K,V}
    nodes = sizehint!(Dict{K,Object{K,V}}(), n)
    node = _ch(root)
    while node isa Object{K,V}
        get!(nodes, _k(node)::K, node)
        node = _ch(node)
    end
    return nodes
end

# an `ObjectClosure` that appends to `obj`, which may already hold entries
function appendclosure(obj::Object{K,V}, ctx) where {K,V}
    oc = ObjectClosure(obj, ctx)
    while _ch(oc.obj) !== notset
        oc.obj = _ch(oc.obj)::Object{K,V}
        oc.count += 1
    end
    if oc.count >= 5
        keys = sizehint!(Set{K}(), oc.count)
        node = _ch(obj)
        while node isa Object{K,V}
            push!(keys, _k(node)::K)
            node = _ch(node)
        end
        oc.keys = keys
    end
    return oc
end

_objectkey(ctx, ::Type, k) = String(k) # untyped parse: keys are Strings
_objectkey(st::StructStyle, ::Type{K}, k) where {K} = StructUtils.liftkey(st, K, k)

# a typed parse with the caller's own style rather than the default one
_customstyle(ctx) = ctx isa StructStyle && !(ctx isa _DefaultReadStyle)

function (oc::ObjectClosure{K,V})(k, v) where {K,V}
    # a custom style's hooks give values of any type, and handing one to the callback below
    # would be a dynamic call, which `juliac --trim` can't compile
    V === Any && !_customstyle(oc.ctx) &&
        return applyvalue(val -> insert_or_overwrite!(oc, _objectkey(oc.ctx, K, k), val), v, oc.ctx)
    val, pos = StructUtils.make(oc.ctx, V, v)
    insert_or_overwrite!(oc, _objectkey(oc.ctx, K, k), val)
    return pos
end

# generic apply `f` to LazyValue, using default types to materialize, depending on type
function applyvalue(f, x::LazyValues, null)
    type = gettype(x)
    if type == JSONTypes.OBJECT
        obj = Object{String,Any}()
        pos = applyobject(_contextcallback(null, ObjectClosure(obj, null)), x)
        f(obj)
        return pos
    elseif type == JSONTypes.ARRAY
        # basically free to allocate 16 instead of Julia-default 8 and avoids
        # a reallocation in many cases
        arr = Vector{Any}(undef, 16)
        resize!(arr, 0)
        pos = applyarray(_contextcallback(null, (_, v) -> applyvalue(val -> push!(arr, val), v, null)), x)
        f(arr)
        return pos
    elseif type == JSONTypes.STRING
        buf = getbuf(x)
        GC.@preserve buf begin
            str, pos = parsestring(x)
            f(String(str))
        end
        return pos
    elseif type == JSONTypes.NUMBER
        num, pos = parsenumber(x)
        if isint(num)
            f(num.int)
        elseif isfloat(num)
            f(num.float)
        elseif isbigint(num)
            f(num.bigint::BigInt)
        else
            f(num.bigfloat::BigFloat)
        end
        return pos
    elseif type == JSONTypes.NULL
        f(_untypednull(null))
        return getpos(x) + 4
    elseif type == JSONTypes.TRUE
        f(true)
        return getpos(x) + 4
    elseif type == JSONTypes.FALSE
        f(false)
        return getpos(x) + 5
    else
        throw(ArgumentError("cannot parse json"))
    end
end

# The typed counterparts of the untyped closures above: `Any` slots under a typed parse and
# the container types the untyped parse produces. A value materializes exactly as the untyped
# parse would, except that the style's object type and null value apply. A target that is
# not the matching JSON kind falls through to the generic `StructUtils.make`.
"""
    JSON.applyvalue(f, x::LazyValue, style::StructUtils.StructStyle) -> pos

Materialize `x` as the untyped `JSON.parse` would, with `style`'s object type and null
value, call `f(value)`, and return the position past `x`. With the default read style,
`value` reaches `f` with its concrete type, so no `(value::Any, pos)` pair is boxed.
Custom styles use their `StructUtils.make` and `StructUtils.lift` hooks instead.
"""
function applyvalue(f, x::LazyValues, st::_DefaultReadStyle)
    type = gettype(x)
    if type == JSONTypes.OBJECT
        obj, pos = StructUtils.make(st, objecttype(st), x)
        f(obj)
        return pos
    elseif type == JSONTypes.ARRAY
        arr, pos = StructUtils.make(st, Vector{Any}, x)
        f(arr)
        return pos
    elseif type == JSONTypes.STRING
        buf = getbuf(x)
        GC.@preserve buf begin
            str, pos = parsestring(x)
            f(String(str))
        end
        return pos
    elseif type == JSONTypes.NUMBER
        num, pos = parsenumber(x)
        if isint(num)
            f(num.int)
        elseif isfloat(num)
            f(num.float)
        elseif isbigint(num)
            f(num.bigint::BigInt)
        else
            f(num.bigfloat::BigFloat)
        end
        return pos
    elseif type == JSONTypes.NULL
        f(nullvalue(st))
        return getpos(x) + 4
    elseif type == JSONTypes.TRUE
        f(true)
        return getpos(x) + 4
    elseif type == JSONTypes.FALSE
        f(false)
        return getpos(x) + 5
    else
        throw(ArgumentError("cannot parse json"))
    end
end

# An object or array value as `make(st, Any, x)` builds it for a custom style, typed as the
# style's object type or `Vector{Any}`.
function _makecontainer(st::StructStyle, x::LazyValues)
    gettype(x) == JSONTypes.ARRAY && return StructUtils.make(st, Vector{Any}, x)
    O = objecttype(st)
    # `_makeobjectvalue` appends in O(n); the generic `makedict` scans the object per key
    st isa JSONReadStyle && O <: Object && return _makeobjectvalue(st, O, x)
    return StructUtils.make(st, O, x)
end

# `_makeobject` for a value already known to be an object, without its fallback into
# StructUtils' generic `make`. Among a custom style's recursive calls that fallback keeps
# `juliac --trim` from compiling them (Julia 1.14) or a later default-style parse (1.13).
function _makeobjectvalue(st::JSONReadStyle, ::Type{O}, x::LazyValues) where {O<:Object}
    obj = StructUtils.initialize(st, O, x)
    pos = applyobject(_contextcallback(st, ObjectClosure(obj, st)), x)
    return obj, pos
end

function StructUtils.make(st::StructStyle, ::Type{Any}, x::LazyValues)
    type = gettype(x)
    if type == JSONTypes.OBJECT || type == JSONTypes.ARRAY
        return _makecontainer(st, x)
    elseif type == JSONTypes.STRING
        return StructUtils.lift(st, String, x)
    elseif type == JSONTypes.NUMBER
        return StructUtils.lift(st, Number, x)
    elseif type == JSONTypes.NULL
        return StructUtils.lift(st, Nothing, x)
    elseif type == JSONTypes.TRUE || type == JSONTypes.FALSE
        return StructUtils.lift(st, Bool, x)
    else
        throw(ArgumentError("cannot parse json"))
    end
end

function applyvalue(f, x::LazyValues, st::StructStyle)
    val, pos = StructUtils.make(st, Any, x)
    f(val)
    return pos
end

function StructUtils.make(st::_DefaultReadStyle, ::Type{Any}, x::LazyValues)
    box = Ref{Any}()
    pos = applyvalue(v -> (box[] = v), x, st)
    return box[], pos
end

function StructUtils.make(st::_DefaultReadStyle, ::Type{Vector{Any}}, x::LazyValues)
    gettype(x) == JSONTypes.ARRAY ||
        return @invoke StructUtils.make(st::StructStyle, Vector{Any}::Type, x::Any)
    arr = sizehint!(StructUtils.initialize(st, Vector{Any}, x), 16)
    pos = applyarray(_contextcallback(st, (_, v) -> applyvalue(val -> push!(arr, val), v, st)), x)
    return arr, pos
end

# `ObjectClosure` with the style as its context appends in O(n) with the untyped path's
# duplicate handling; the generic `makedict` went through `setindex!`, a linear scan per key.
function _makeobject(st::JSONReadStyle, ::Type{O}, x::LazyValues) where {O<:Object}
    gettype(x) == JSONTypes.OBJECT ||
        return @invoke StructUtils.make(st::StructStyle, O::Type, x::Any)
    obj = StructUtils.initialize(st, O, x)
    pos = applyobject(_contextcallback(st, ObjectClosure(obj, st)), x)
    return obj, pos
end

StructUtils.make(st::_DefaultReadStyle, ::Type{O}, x::LazyValues) where {O<:Object} = _makeobject(st, O, x)
# `JSON.parse!` into an existing `Object`: entries are added or updated as with `setindex!`
function StructUtils.make!(st::_DefaultReadStyle, obj::Object, x::LazyValues)
    gettype(x) == JSONTypes.OBJECT ||
        return @invoke StructUtils.make!(st::StructStyle, obj::Any, x::Any)
    return applyobject(_contextcallback(st, appendclosure(obj, st)), x)
end
# `Object{String,Any}` is also an `AbstractDict{String,Any}`, which has its own method below
StructUtils.make(st::_DefaultReadStyle, ::Type{Object{String,Any}}, x::LazyValues) =
    _makeobject(st, Object{String,Any}, x)

function StructUtils.make(st::_DefaultReadStyle, ::Type{T}, x::LazyValues) where {T<:AbstractDict{String,Any}}
    gettype(x) == JSONTypes.OBJECT ||
        return @invoke StructUtils.make(st::StructStyle, T::Type, x::Any)
    dict = StructUtils.initialize(st, T, x)
    pos = applyobject(_contextcallback(st, (k, v) -> applyvalue(val -> StructUtils.addkeyval!(dict, StructUtils.liftkey(st, String, k), val), v, st)), x)
    return dict, pos
end

# catch PtrString via lift or make! so we can ensure it never "escapes" to user-level
StructUtils.liftkey(st::JSONReadStyle, ::Type{T}, x::PtrString) where {T} =
    StructUtils.liftkey(st, T, String(x))
StructUtils.lift(st::JSONReadStyle, ::Type{T}, x::PtrString, tags) where {T} =
    StructUtils.lift(st, T, String(x), tags)
StructUtils.lift(st::JSONReadStyle, ::Type{T}, x::PtrString) where {T} =
    StructUtils.lift(st, T, String(x))

# liftkey for numeric dict key types to enable round-tripping Dict{Int,V}, Dict{Float64,V}, etc.
# these correspond to the lowerkey definitions in write.jl that convert numeric keys to strings
StructUtils.liftkey(::JSONReadStyle, ::Type{T}, x::AbstractString) where {T<:Integer} = Base.parse(T, x)
StructUtils.liftkey(::JSONReadStyle, ::Type{T}, x::AbstractString) where {T<:AbstractFloat} = Base.parse(T, x)

_isliftpair(x) = x isa Tuple && !(x isa NamedTuple) && length(x) == 2
_liftresult(x, st) = _isliftpair(x) ? x : (x, StructUtils.defaultstate(st))
_liftresult(x, pos::Int) = _isliftpair(x) ? x : (x, pos)

struct _NoCustomLazyLift end
const _NO_CUSTOM_LAZY_LIFT = _NoCustomLazyLift()

StructUtils.lift(::JSONStyle, ::Type{T}, ::LazyValues, tags) where {T} = _NO_CUSTOM_LAZY_LIFT
StructUtils.lift(::JSONStyle, ::Type{T}, ::LazyValues) where {T} = _NO_CUSTOM_LAZY_LIFT

StructUtils.lift(style::JSONReadStyle, ::Type{T}, x, tags) where {T} =
    _liftresult(StructUtils.lift(style.style, T, x, tags), style)
StructUtils.lift(style::JSONReadStyle, ::Type{T}, x) where {T} =
    _liftresult(StructUtils.lift(style.style, T, x), style)

function customlazylift(style::JSONReadStyle, ::Type{T}, x::LazyValues, tags) where {T}
    inner = style.style
    inner isa JSONStyle || return nothing
    ret = StructUtils.lift(inner, T, x, tags)
    ret === _NO_CUSTOM_LAZY_LIFT || return _liftresult(ret, skip(x))
    ret = StructUtils.lift(inner, T, x)
    ret === _NO_CUSTOM_LAZY_LIFT || return _liftresult(ret, skip(x))
    return nothing
end

function StructUtils.lift(style::JSONReadStyle, ::Type{T}, x::LazyValues) where {T<:AbstractArray{E,0}} where {E}
    m = T(undef)
    m[1], pos = StructUtils.lift(style, E, x)
    return m, pos
end

function StructUtils.lift(style::JSONReadStyle, ::Type{T}, x::LazyValues, tags=(;)) where {T}
    type = gettype(x)
    buf = getbuf(x)
    if type == JSONTypes.OBJECT || type == JSONTypes.ARRAY
        custom = customlazylift(style, T, x, tags)
        custom === nothing || return custom
    end
    if type == JSONTypes.STRING
        GC.@preserve buf begin
            ptrstr, pos = parsestring(x)
            str, _ = StructUtils.lift(style, T, ptrstr, tags)
        end
        return str, pos
    elseif type == JSONTypes.NUMBER
        num, pos = parsenumber(x, T)
        # the returns below skip `lift`, so they're only taken when a `lift` tag or the
        # caller's style can't change the value
        direct = style isa _DefaultReadStyle && !haskey(tags, :lift)
        if isint(num)
            direct && T === Int64 && return num.int, pos
            int, _ = StructUtils.lift(style, T, num.int, tags)
            return int, pos
        elseif isfloat(num)
            direct && T === Float64 && return num.float, pos
            float, _ = StructUtils.lift(style, T, num.float, tags)
            return float, pos
        elseif isbigint(num)
            direct && T === BigInt && return num.bigint::BigInt, pos
            bigint, _ = StructUtils.lift(style, T, num.bigint::BigInt, tags)
            return bigint, pos
        else
            direct && T === BigFloat && return num.bigfloat::BigFloat, pos
            bigfloat, _ = StructUtils.lift(style, T, num.bigfloat::BigFloat, tags)
            return bigfloat, pos
        end
    elseif type == JSONTypes.NULL
        null, _ = StructUtils.lift(style, T, nullvalue(style), tags)
        return null, getpos(x) + 4
    elseif type == JSONTypes.TRUE
        tr, _ = StructUtils.lift(style, T, true, tags)
        return tr, getpos(x) + 4
    elseif type == JSONTypes.FALSE
        fl, _ = StructUtils.lift(style, T, false, tags)
        return fl, getpos(x) + 5
    elseif Base.issingletontype(T)
        sglt, _ = StructUtils.lift(style, T, T(), tags)
        return sglt, skip(x)
    else
        # an object or array materializes like the untyped parse, with this parse's options
        # (with the default ones, that is the untyped path itself)
        plain = style isa JSONReadStyle{DEFAULT_OBJECT_TYPE,Nothing,StructUtils.DefaultStyle,Nothing}
        if T === Any && !plain
            val1, pos = _customstyle(style) ? _makecontainer(style, x) : StructUtils.make(style, Any, x)
            # a `lift` tag or a custom style's `lift` still applies to the materialized value
            style isa _DefaultReadStyle && !haskey(tags, :lift) && return val1, pos
            val, _ = StructUtils.lift(style, T, val1, tags)
            return val, pos
        end
        if _customstyle(style)
            val1, pos = _makecontainer(style, x)
        else
            out = ValueClosure()
            pos = plain ? applyvalue(out, x, nothing) : applyvalue(out, x, style)
            val1 = out.value
        end
        # big switch here for --trim verify-ability
        if val1 isa objecttype(style)
            val, _ = StructUtils.lift(style, T, val1, tags)
            return val, pos
        elseif val1 isa Vector{Any}
            val, _ = StructUtils.lift(style, T, val1, tags)
            return val, pos
        elseif val1 isa String
            val, _ = StructUtils.lift(style, T, val1)
            return val, pos
        elseif val1 isa Int64
            val, _ = StructUtils.lift(style, T, val1)
            return val, pos
        elseif val1 isa Float64
            val, _ = StructUtils.lift(style, T, val1)
            return val, pos
        elseif val1 isa BigInt
            val, _ = StructUtils.lift(style, T, val1)
            return val, pos
        elseif val1 isa BigFloat
            val, _ = StructUtils.lift(style, T, val1)
            return val, pos
        elseif val1 isa Bool
            val, _ = StructUtils.lift(style, T, val1)
            return val, pos
        elseif val1 isa Nothing
            val, _ = StructUtils.lift(style, T, val1)
            return val, pos
        else
            throw(ArgumentError("cannot parse json"))
        end
    end
end

function StructUtils.make(::StructStyle, ::Type{JSONText}, x::LazyValues)
    buf = getbuf(x)
    pos = getpos(x)
    endpos = skip(x)
    val = GC.@preserve buf JSONText(unsafe_string(pointer(buf, pos), endpos - pos))
    return val, endpos
end

# `unknownfield` for a member past a tuple's length; under `error_context=true` a rejection
# points at that member, as it does for a struct's unknown field
@inline unknownmember(st, ::Type{T}, key, x) where {T} =
    _contextcallback(st, (k, v) -> StructUtils.unknownfield(st, T, k, v))(key, x)

# The members of a tuple's source past its `i`th, from `pos` (where the next one starts) to
# the closing bracket; returns the position after it. Each member goes to `unknownfield`, as
# a struct's unknown field does: skipped by default, rejected with `unknown_fields=:error`.
@noinline function skipmembers(st, ::Type{T}, buf, pos::Int, len, b, typ, opts, depth, i::Int) where {T}
    local error::Error # set inside the loop, read at the label after it
    while true
        i += 1
        GC.@preserve buf begin
            if typ == JSONTypes.OBJECT
                key, pos = @inline parsestring(LazyValue(buf, pos, JSONTypes.STRING, opts, false, depth))
                @nextbyte
                if b != UInt8(':')
                    error = ExpectedColon
                    @goto invalid
                end
                pos += 1
                @nextbyte
                x = _lazy(buf, pos, len, b, opts, false, depth)
                ret = unknownmember(st, T, key, x)
            else
                x = _lazy(buf, pos, len, b, opts, false, depth)
                ret = unknownmember(st, T, i, x)
            end
        end
        pos = (ret isa Int && ret > pos) ? ret : skip(x)
        @nextbyte
        if b == (typ == JSONTypes.OBJECT ? UInt8('}') : UInt8(']'))
            return pos + 1
        elseif b != UInt8(',')
            error = ExpectedComma
            @goto invalid
        end
        pos += 1
        @nextbyte
    end
@label invalid
    invalid(error, buf, pos, "tuple")
end

@noinline jsonlinestuple() = throw(ArgumentError("JSON Lines input can't be read as a tuple; parse it as a vector"))

@generated function StructUtils.maketuple(st::StructStyle, ::Type{T}, x::LazyValues) where {T<:Tuple}
    N = fieldcount(T)
    ex = quote
        pos::Int = getpos(x)
        buf = getbuf(x)
        len = getlength(buf)
        opts = getopts(x)
        # a JSON Lines input has no brackets (and an empty one starts past its last byte)
        opts.jsonlines && jsonlinestuple()
        b = getbyte(buf, pos)
        typ = gettype(x)
        depth = getdepth(x) + Int32(1)
        depth > opts.maxdepth && toodeep(pos, opts.maxdepth)
        if typ == JSONTypes.OBJECT && b != UInt8('{')
            error = ExpectedOpeningObjectChar
            @goto invalid
        elseif typ == JSONTypes.ARRAY && b != UInt8('[')
            error = ExpectedOpeningArrayChar
            @goto invalid
        elseif typ != JSONTypes.OBJECT && typ != JSONTypes.ARRAY
            error = InvalidJSON
            @goto invalid
        end
        pos += 1
        @nextbyte
        # an empty tuple reads no members: only its source's closing bracket, or extra members
        $(N == 0 ? :(b == (typ == JSONTypes.OBJECT ? UInt8('}') : UInt8(']')) && return (), pos + 1) : nothing)
        Base.@nexprs $N i -> begin
            if typ == JSONTypes.OBJECT
                # consume key
                GC.@preserve buf begin
                    _, pos = @inline parsestring(LazyValue(buf, pos, JSONTypes.STRING, opts, false, depth))
                end
                @nextbyte
                if b != UInt8(':')
                    error = ExpectedColon
                    @goto invalid
                end
                pos += 1
                @nextbyte
            end
            x = _lazy(buf, pos, len, b, opts, false, depth)
            j_{i}, pos = _contextmake(st, fieldtype(T, i), x)
            @nextbyte
            if typ == JSONTypes.OBJECT && b == UInt8('}')
                if Base.@nany($N, k->!@isdefined(j_{k}))
                    error = InvalidJSON
                    @goto invalid
                end
                return Base.@ntuple($N, j), pos + 1
            elseif typ == JSONTypes.ARRAY && b == UInt8(']')
                if Base.@nany($N, k->!@isdefined(j_{k}))
                    error = InvalidJSON
                    @goto invalid
                end
                return Base.@ntuple($N, j), pos + 1
            elseif b != UInt8(',')
                error = ExpectedComma
                @goto invalid
            end
            pos += 1
            @nextbyte
        end
        return Base.@ntuple($N, j), skipmembers(st, T, buf, pos, len, b, typ, opts, depth, $N)
        @label invalid
        invalid(error, buf, pos, "tuple")
    end
    return ex
end
