module JSON

# stdlibs
using Dates, UUIDs, Logging
# external dependencies
using PrecompileTools, Parsers, StructUtils

# reexport some StructUtils macros
import StructUtils: @noarg, @kwarg, @defaults, @tags, @choosetype, @nonstruct, lower, lift
export JSONText, StructUtils, @noarg, @kwarg, @defaults, @tags, @choosetype, @nonstruct, @omit_null, @omit_empty

# Mark documented API as `public` on Julia versions that support it (>= 1.11).
# Wrapped in `eval(Expr(...))` because `public` is a parse error on older versions.
@static if VERSION >= v"1.11"
    eval(Expr(:public,
        :parse, :parse!, :parsefile, :parsefile!,
        :lazy, :lazyfile, :LazyValue,
        :isvalidjson, :DuplicateKeyError, :ParseError,
        :json, :print,
        :lower, :lift,
        :omit_null, :omit_empty,
        :Object, :Null, :Omit, :JSONStyle,
    ))
end

"""
    JSON.DuplicateKeyError

Error thrown when `duplicate_keys=:error` encounters a repeated object key.
`key` is the decoded JSON key and `position` is its one-based byte position.
"""
struct DuplicateKeyError <: Exception
    key::String
    position::Int
end

function Base.showerror(io::IO, err::DuplicateKeyError)
    Base.print(io, "duplicate JSON object key ", repr(err.key), " at byte position ", err.position)
end

"""
    JSON.ParseError

An error encountered while constructing a value with `error_context=true`.
`path` is an RFC 6901 JSON Pointer relative to the input value, or `nothing`
if the path could not be recovered. Array indices are zero-based. `position`
is the one-based start byte of the failing value in the original input buffer.
`cause` and `backtrace` retain the original exception and its backtrace.
"""
struct ParseError <: Exception
    path::Union{Nothing,String}
    position::Int
    cause::Any
    backtrace::Any
end

function Base.showerror(io::IO, err::ParseError)
    Base.print(io, "JSON parse error")
    err.path === nothing || Base.print(io, " at ", repr(err.path))
    Base.print(io, " (value starts at byte ", err.position, "): ")
    Base.showerror(io, err.cause)
end

@enum Error InvalidJSON UnexpectedEOF ExpectedOpeningObjectChar ExpectedOpeningQuoteChar ExpectedOpeningArrayChar ExpectedClosingArrayChar ExpectedComma ExpectedColon ExpectedNewline InvalidChar InvalidNumber InvalidUTF16 InvalidEscape

@generated _typename(::Type{T}) where {T} = QuoteNode(string(T))

@noinline invalid(error, buf, pos::Int, ::Type{T}) where {T} =
    _invalid(error, buf, pos, _typename(T))
@noinline invalid(error, buf, pos::Int, typename::String) =
    _invalid(error, buf, pos, typename)

@noinline function _invalid(error, buf, pos::Int, typename::String)
    # compute which line the error falls on by counting “\n” bytes up to pos
    cus = buf isa AbstractString ? codeunits(buf) : buf
    # `pos` can point one byte past the end: UnexpectedEOF is reported at the
    # position we wanted to read, so every input ending mid-token lands here
    # with pos == sizeof(cus) + 1. Clamp before slicing, or building the error
    # message throws BoundsError instead of the ArgumentError we mean to raise.
    n = getlength(buf)
    line_no = count(b -> b == UInt8('\n'), view(cus, 1:min(pos, n))) + 1

    li = pos > 20 ? min(pos - 9, n) : 1
    ri = min(n, pos + 20)
    snippet_bytes = cus[li:ri]
    snippet_pos = pos - li + 1
    # control characters print as one space, so replace them before measuring widths
    snippet = replace(String(copy(snippet_bytes)), r"[\b\f\n\r\t]" => " ")
    # find error position; if snippet has multi-codepoint chars,
    # translate pos to char index, accounting for textwidth of char
    erri = 1
    st = iterate(snippet)
    while st !== nothing
        c, i = st
        i > snippet_pos && break
        erri += textwidth(c)
        st = iterate(snippet, i)
    end
    # we call @invoke here to avoid --trim verify errors
    caret = @invoke(repeat(" "::String, (erri - 1)::Integer)) * "^"
    msg = """
    invalid JSON at byte position $(pos) (line $line_no) parsing type $(typename): $error
    $snippet$(error == UnexpectedEOF ? " <EOF>" : "...")
    $caret
    """
    throw(ArgumentError(msg))
end

# Parsing recurses once per nested object/array, so input nested deeper than
# `maxdepth` is refused up front rather than overflowing the stack.
@noinline toodeep(pos::Int, maxdepth::Int32) = throw(ArgumentError(string(
    "JSON nesting depth at byte position ", pos, " exceeds the `maxdepth` limit of ", maxdepth,
    "; pass a larger `maxdepth` keyword argument to parse deeper input")))

include("utils.jl")
include("object.jl")

# default object type for parse
const DEFAULT_OBJECT_TYPE = Object{String, Any}

"""
    JSON.JSONText

Wrapper around a string containing JSON data.
Can be used to insert raw JSON in JSON output, like:
```julia
json(JSONText("{\"key\": \"value\"}"))
```
This will output the JSON as-is, without escaping.
Note that no check is done to ensure that the JSON is valid.

Can also be used to read "raw JSON" when parsing, meaning
no specialized structure (JSON.Object, Vector{Any}, etc.) is created.
Example:
```julia
x = JSON.parse("[1,2,3]", JSONText)
# x.value == "[1,2,3]"
```
"""
struct JSONText
    value::String
end

JSONText(x::JSONText) = x

include("lazy.jl")
include("parse.jl")
include("write.jl")

"""
    JSON.isvalidjson(json) -> Bool

Check if the given JSON is valid.
This function will return `true` if the JSON is valid, and `false` otherwise.
Inputs can be a string, a vector of bytes, or an IO stream, the same inputs
as supported for `JSON.lazy` and `JSON.parse`.
"""
function isvalidjson end

isvalidjson(io::Union{IO, Base.AbstractCmd}; kw...) = isvalidjson(Base.read(io); kw...)

# invalid input throws one of these; anything else (a bad keyword, an interrupt) is rethrown
isinvalidjson(e) = e isa Union{ArgumentError, DuplicateKeyError}

function isvalidjson(buf::Union{AbstractVector{UInt8}, AbstractString}; kw...)
    try
        return isvalidjson(lazy(buf; kw...))
    catch e
        isinvalidjson(e) || rethrow()
        return false
    end
end

function isvalidjson(x::LazyValue)
    try
        pos = skip(x)
        getisroot(x) && checkendpos(x, Any, pos)
        return true
    catch e
        isinvalidjson(e) || rethrow()
        return false
    end
end

# convenience aliases for pre-1.0 JSON compat
print(io::IO, obj, indent=nothing) = json(io, obj; pretty=something(indent, 0))
print(a, indent=nothing) = print(stdout, a, indent)

"See [`json`](@ref)."
print

# typed-parse workload struct: exercising one struct with the common field
# shapes caches the shared make/lift/array-chain inference in this package's
# image, so downstream typed parses hit those caches instead of re-inferring
# (which also keeps `juliac --trim` edge inference precise on nested families)
struct _WorkloadInner
    x::Int
    y::Float64
end
struct _Workload
    item::Union{Nothing,_WorkloadInner}
    items::Vector{_WorkloadInner}
    tags::Vector{String}
    note::Union{Nothing,String}
end

@compile_workload begin
    x = JSON.parse("{\"a\": 1, \"b\": null, \"c\": true, \"d\": false, \"e\": \"\", \"f\": [1,null,true], \"g\": {\"key\": \"value\"}}")
    json = JSON.json(x)
    isvalidjson(json)
    # hand-built `Dict{String,Any}`s don't share compiled write code with parsed
    # `JSON.Object`s. Skipped on Julia 1.10: there it leaves two cached code
    # instances for some `JSON.Object` write methods, 1.10 revalidates only one
    # per method on load, and the `JSON.Object` writes then recompile on first use.
    VERSION >= v"1.11" && JSON.json(Dict{String,Any}("a" => 1, "b" => nothing, "c" => true, "d" => 1.5, "e" => "", "f" => Any[1, nothing, true, Dict{String,Any}("key" => "value")]))
    typed = "{\"item\":{\"x\":1,\"y\":2.0},\"items\":[{\"x\":3,\"y\":4.0}],\"tags\":[\"p\"],\"note\":null}"
    JSON.parse(typed, _Workload)
    # byte-vector input (`read(file)`, file and stream input, HTTP bodies) compiles
    # the parser separately from `String` input
    bytes = Vector{UInt8}(json)
    JSON.parse(bytes)
    isvalidjson(bytes)
    JSON.parse(Vector{UInt8}(typed), _Workload)
end


end # module
